import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

type Role = "Student" | "Industry" | "Academician" | "Institution";

const roleInfo: Record<Role, { icon: string; text: string }> = {
  Student: { icon: "🎓", text: "Build skills, find internships and prepare for placements." },
  Industry: { icon: "🏢", text: "Map industry skills, post internships and discover talent." },
  Academician: { icon: "👩‍🏫", text: "Align teaching with current industry requirements." },
  Institution: { icon: "🏫", text: "Track skill gaps, partnerships and placement outcomes." }
};

const internships = [
  { company: "TechNova", role: "Frontend Development Intern", skills: "React · TypeScript", mode: "Hybrid" },
  { company: "DataSphere", role: "Data Analytics Intern", skills: "Python · SQL", mode: "Remote" },
  { company: "FinEdge", role: "Finance & Business Analytics", skills: "Excel · Power BI", mode: "On-site" }
];

function App() {
  const [role, setRole] = useState<Role>("Student");
  const [signedIn, setSignedIn] = useState(false);

  return (
    <div className="app">
      <header className="nav">
        <div className="brand">
          <div className="logo">SB</div>
          <span>SkillBridge</span>
        </div>
        <div className="nav-actions">
          <a href="#features">Features</a>
          <a href="#internships">Internships</a>
          <button className="signin" onClick={() => setSignedIn(v => !v)}>
            {signedIn ? "Dashboard" : "Sign in"}
          </button>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero-card">
            <div className="pill">● SMART EDUCATION · SOFTWARE</div>
            <h1>Skills in.<br />Careers out.</h1>
            <p>
              SkillBridge is a unified academia–industry collaboration portal
              that puts students, industries, academicians and institutions on
              one role-based platform for skill development, internships and placements.
            </p>
            <div className="hero-buttons">
              <a className="primary" href="#roles">Explore SkillBridge</a>
              <a className="secondary" href="#internships">View internships</a>
            </div>
          </div>
        </section>

        <section id="roles" className="section">
          <div className="section-head">
            <div>
              <span className="eyebrow">ONE PLATFORM · FOUR ROLES</span>
              <h2>Connect the complete ecosystem</h2>
            </div>
            <p>Choose a role to preview the experience.</p>
          </div>

          <div className="role-grid">
            {(Object.keys(roleInfo) as Role[]).map(r => (
              <button
                key={r}
                className={`role-card ${role === r ? "selected" : ""}`}
                onClick={() => setRole(r)}
              >
                <span className="role-icon">{roleInfo[r].icon}</span>
                <h3>{r}</h3>
                <p>{roleInfo[r].text}</p>
              </button>
            ))}
          </div>

          <div className="dashboard">
            <div className="dash-top">
              <div>
                <span className="eyebrow">{role.toUpperCase()} DASHBOARD</span>
                <h2>{role === "Student" ? "Your career journey" : `Welcome to your ${role.toLowerCase()} workspace`}</h2>
              </div>
              <span className="status">● Active</span>
            </div>

            <div className="stats">
              <div><strong>{role === "Student" ? "68%" : "24"}</strong><span>{role === "Student" ? "Skill readiness" : "Active connections"}</span></div>
              <div><strong>{role === "Student" ? "12" : "18"}</strong><span>{role === "Student" ? "Skills mapped" : "Opportunities"}</span></div>
              <div><strong>{role === "Student" ? "7" : "86%"}</strong><span>{role === "Student" ? "Recommended paths" : "Engagement"}</span></div>
            </div>

            <div className="progress-box">
              <div className="progress-title"><span>Skill-gap analysis</span><b>68%</b></div>
              <div className="progress"><span style={{width: "68%"}} /></div>
              <p>Identify missing competencies and get targeted learning recommendations.</p>
            </div>
          </div>
        </section>

        <section id="features" className="section light">
          <div className="section-head">
            <div>
              <span className="eyebrow">CORE FEATURES</span>
              <h2>From skills to opportunities</h2>
            </div>
          </div>
          <div className="feature-grid">
            {[
              ["🎯", "Skill Mapping", "Compare current competencies with target career and industry requirements."],
              ["💼", "Internships", "Connect learners with relevant industry internships and practical exposure."],
              ["📈", "Placement Readiness", "Track progress, assessments and job-readiness milestones."],
              ["🤝", "Academia–Industry", "Create a shared space for institutions and companies to collaborate."]
            ].map(([icon, title, text]) => (
              <article className="feature" key={title}>
                <span>{icon}</span><h3>{title}</h3><p>{text}</p>
              </article>
            ))}
          </div>
        </section>

        <section id="internships" className="section">
          <div className="section-head">
            <div>
              <span className="eyebrow">OPPORTUNITIES</span>
              <h2>Recommended internships</h2>
            </div>
            <button className="secondary-btn">View all</button>
          </div>
          <div className="internship-list">
            {internships.map(item => (
              <article className="internship" key={item.role}>
                <div className="company-logo">{item.company.slice(0, 2).toUpperCase()}</div>
                <div className="internship-main">
                  <h3>{item.role}</h3>
                  <p>{item.company} · {item.skills}</p>
                </div>
                <span className="mode">{item.mode}</span>
                <button className="apply">Apply</button>
              </article>
            ))}
          </div>
        </section>

        <section className="cta">
          <div>
            <span className="eyebrow">SKILLBRIDGE</span>
            <h2>Build skills that move careers forward.</h2>
            <p>A unified prototype for students, industry, academia and institutions.</p>
          </div>
          <a className="primary" href="#roles">Get started</a>
        </section>
      </main>

      <footer>
        <strong>SkillBridge</strong>
        <span>Academia · Industry · Skills · Careers</span>
      </footer>
    </div>
  );
}

createRoot(document.getElementById("root")!).render(
  <React.StrictMode><App /></React.StrictMode>
);
